
  # E-commerce site for Do' Motoculture

  This is a code bundle for E-commerce site for Do' Motoculture. The original project is available at https://www.figma.com/design/vza9hCx6wDkgcF7eyAMq98/E-commerce-site-for-Do--Motoculture.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  